```bash
# SMB
# Creds found in 192.168.28.105 FTP server for 192.168.28.120
nmap -sT -Pn 192.168.150.245 -p 445 --script smb-os-discovery


```

Day 1 Network Map

![image-20251210143437120](../Images/image-20251210143437120.png)