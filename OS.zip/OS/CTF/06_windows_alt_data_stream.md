```powershell
Get-ChildItem -Force
# List all files in the current directory

Get-FileHash -Algorithm SHA512
# Command to give the SHA512 hash of a file

Get-ACL
# List permissions of a file

/etc/hosts
#File that maps hostnames to IP addresses

(Get-Acl -Path "C:\Windows\System32\drivers\etc\hosts").Access
# Finds the current permissions for the file hosts

(Get-Acl -Path "C:\Windows\System32\drivers\etc\hosts").Access | Format-Table IdentifyReference
# Further narrows this down to see groups

Get-ChildItem C:\Users\CTF\ -R -Filter "*readme*"
#Search for a file

Get-ChildItem C:\Users\CTF\ -H
# Search for hidden folders / files

Get-ChildItem C:\Users\CTF\ -R -H -Filter *.txt
# Search for a hidden file , specifically .txt

```

