```powershell
#The HKEY_CURRENT_USER applies to the current user. There is a link from HKCU to HKU. Find the SSID of the current user and plug it in. 

Get-ChildItem
#will list all the subkeys and contents in the current directory and/or will list all the subkeys and the contents of a directory you specify

Get-Item
#will list only the contents of a registry key or subkey

HKLM:\Software\Microsoft\Windows\CurrentVersion\Run
# Runs every time system reboots

HKCU:\Software\Microsoft\Windows\CurrentVersion\Run
# Runs every time a user logs on

HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce
# Runs a single time, then deletes its value once the machine reboots

HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce
# Runs a single time, then deletes its value when a user logs on

Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\
# Malicious malware may be located here - This registry subkey has startup software

#If you cannot query the HKU:\ Registry you need to create a PS Drive:
New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS
#Now you can query
Get-Item HKU:\S-1-5-21-2881336348-3190591231-4063445930-1003\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\

Get-Item HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce
#Will give you the value of the key from run-once system

Get-Item HKU:\S-1-5-21-2881336348-3190591231-4063445930-1003\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
#Will give you the value of the key from a certain SID from run-once user

get-item HKLM:\SYSTEM\CurrentControlSet\Enum\USBSTOR
#Will show you the USB information. Get-ItemProperty will also work

Get-Item 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\*'
#Will show you all profiles within the profilelist and details

Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles\*'
# Will show you the network wifi SSID's and some more information 
```

