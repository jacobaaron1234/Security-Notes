```bash
#Locate the executable that started a process:
sudo ls -l /proc/22743 #22743 is the PID

sudo lsof -p 1330
#Identifies the files designated aby (0r,11w,2w,3u, etc) that are mapped to file descriptors (handle)

watch -n 5 ps --ppid 1 -lf
#Watches the process changes for ppid 1 every 5 seconds

ps f -elf 
# to see the tree version. This shows parent processes to Zombies

watch -n 2 'ps f -elf | tail -n20'
sudo lsof -p 4585 # PPID of Zombie process

Grep -R '*.txt' / 2>/dev/null #Finds strings with .txt

systemctl list-units --type=service

systemctl cat passwd.service #Read a service

```

