```powershell
AllUsersAllHosts 
#has the lowest precedence 

CurrentUserCurrentHost 
#has the highest precedence

$HOME
#Stores the current users home directory

$PsHome         
#Stores the installation directory for PowerShell

$Profile
#Stores the current user current host

Test-Path -Path $profile.AllUsersAllHosts
#Lets us know if there's a profile loaded for allusers_allhosts

get-content $PROFILE.CurrentUserCurrentHost
#Reads stuff in this profile
```

