```powershell
.\accesschk.exe -p spoolsv.exe
#View permissions on an executable service

.\handle.exe | findstr /i "spool"
# Used to find the file path of spoolsv service. 

#Use LoadOrder sysinternal tool to find load order group. 


```

