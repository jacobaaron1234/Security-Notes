```bash
man --path cat
#Shows the path to the cat binary man page

#Search man pages for a keyword and encrypt to sha512
man -k digest
echo OneWayBestWay | sha512sum

#decrypt from aes-128
openssl enc -d -aes-128-cbc -in cipher -out decipher

wc -l file.txt && wc -l file.txt
#Finds wc with lines of mulitple files

cat /etc/passwd | cut -d ':' -f 1,7 | grep -v -e /usr/sbin/nologin
# Cuts the file and removes a string

sudo -u *username* ./executable
# use -u to run a file as someone else

ls -d /etc/* | grep -P "(\.d$)" | wc
# Finds directories and specifically for . and d. The $ means at the end

grep -P "\b\d{1,3}(?:\.\d{1,3}){3}\b"
# The \b is a boundary
# \d{1,3} matches for any demcial from 1 to 3 digits
# ?: associates a pattern
# \.\d{1,3} is the pattern of dot then any decimal from 1 to 3 digits
#{3} repeats the last 3 times

cat numbers | grep -P '\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\.|$)){4}\b' 
#God help us all. Matches for valid IP addresses 

cat numbers | grep -P '^(?i)(?:[0-9a-z]{2}([:-]))(?:[0-9a-z]{2}\1){4}[0-9a-z]{2}$' 
# Matches for MAC addresses. Replace 'z' with 'f' for true MAC addresses. 

cat numbers | awk 'NR >= 420 && NR <= 1337'| sha512sum
# Using awk within a range of lines (See man awk ---> NR)

awk -F'\t' -v OFS="," '{print $1,$2,$3,$4,$5,$6}' connections > output.csv
# uses awk to create a new file with the first 6 columns
# -F is the field seperator. '\t' is by TAB spacing
# -v is the output field seperator (OFS). "," comma deliniation 
# {print $1, etc} is printing the first 6 columns only

cat paths | grep -Ff binlist.txt
# binlist.txt is the list of binaries from usr/bin. "ls /usr/bin > binlist.txt"
# We use -f for which file and -F for literal match (no regex)

cat guardsmen | awk '{ gsub(/,/, "\n"); print }' > newguard
#This awk replaces commas with new lines
```

