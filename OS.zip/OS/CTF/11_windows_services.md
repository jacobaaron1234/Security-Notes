```cmd
sc queryex type=service state=all
#Shows all services, running or not running.

sc showsid servicename
#Shows SID of service. CMD command
```

