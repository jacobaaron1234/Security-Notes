```powershell
cmdscan
# Plugin used to search for command history in Volatility 

driverscan
# Plugin used to scan for driver objects

.\volatility_2.6_win64_standalone.exe -f ".\0zapftis.vmem" --profile=WinXPSP2x86 cmdscan
# Find commands run in this memory file

.\volatility_2.6_win64_standalone.exe -f ".\0zapftis.vmem" --profile=WinXPSP2x86 driverscan
#Used to find driver objects within this file

Get-FileHash -Algorithm md5 .\executable.544.exe
#Get Md5 hash in PowerShell

```

