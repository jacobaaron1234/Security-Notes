```powershell
HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\
#Location of UAC settings

HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
#Check this as well for UAC settings


```

