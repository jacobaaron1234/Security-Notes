```powershell
Get-Item C:\Windows\System32\drivers\etc\hosts | select FullName,LastAccessTime
# Shows name and Last Access Time of the hosts file on Windows

```

