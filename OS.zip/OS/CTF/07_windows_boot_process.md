Initial setup for this lab:

```bat
scp -r andy.dwyer@10.50.12.134:c:/users/andy.dwyer/desktop/Win_Bootkit.vdi.7z .

#Install needed apps
sudo apt install qemu-utils qemu-system-x86 p7zip-full -y

#Extract
p7zip -d Win_Bootkit.vdi.7z Win_Bootkit.vdi

#Start
qemu-system-x86_64 -device usb-ehci -m 2G -net none Win_Bootkit.vdi

```

In the lab:

```bat
shutdown /a 
# Abort a shutdown

bcdedit /set {bootmgr} timeout 29
# Sets the timeout to 29. If 0, boot will continously run

bcdedit /deletevalue {current} safeboot
# disables the automatic loadup of safeboat

services.msc
#GUI view of services
```

