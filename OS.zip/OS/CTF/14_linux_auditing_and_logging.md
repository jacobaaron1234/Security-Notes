auth,authpriv,8,10.30.0.1

```bash
xpath -q -e '//@addr/' output.xml | md5sum
#Will give you all addr attributes from output.xml

xpath -q -e '//@addr|//@portid' output.xml | md5sum
# will give you all the addr and portid attributes

xpath -q -e ' //*[@state="open"]/../@portid | //*[@state="open"]/../../..//@addr ' output.xml
# Will give you portid and address if they are open.

jq '."id.orig_h"' conn.log | sort -u | wc -l
# Sort the originating hosts uniquely and count

jq -s '[.[] | select(.resp_ip_bytes > 40)] | length' conn.log
# Not sure what's going on here

sudo journalctl -F _UID
# searches a log for user IDs and prints them

```

![image-20251105134259664](../Images/image-20251105134259664.png)