```powershell
findstr /i *string*
#finds a string within files

get-process | get-member -MemberType Property | Measure-Object
# Gets the count of the properties within get-process cmdlet

Get-CimInstance -ClassName Win32_Service -filter "Name='NameofTheService'" | Select-Object Description
#find description of a service

Get-Content *file.txt* | Measure-Object
#Count the words within a document

Get-ChildItem | Measure-Object
#Read the number of files in a directory

Compare-Object (cat file1.txt) (cat file2.txt)
#compare two outputs in two files for differences 

Get-Content file.txt | sort-object | sort-object -Descending | Select-Object -Index 99 
#Select a specific line number from file.txt, alphabetically sorted, descending 

Get-Content file.txt.txt | sort-object -Unique | Measure-Object
#Sorts file contents by unique and then counts the number remaining. Unique removes all that are not unique

Get-Process | Get-Member -MemberType Method | Measure-Object
# Get-Member finds the members, properties, and methods of objects
#This command finds the properties of Get-Process, specifically the Method, and counts it

Get-Content words.txt | Select-String 'gaab' | measure-object
#Cats a file, searches for a string 'gaab' (case-insensitive) and counts it

Get-Content file.txt | Where-Object {$_ -match 'a' -or $_ -match 'z'} | Measure-Object
#Where-Object selects and object based on its property values
# cats every line and matches it with either 'a' or 'z' and then counts it. 
#The $_ (You can think of $_ as = current line) is what makes it check every line

Get-Content file.txt | Where-Object {$_ -match 'aaa' -or $_ -match 'aab' -or $_ -match 'aac' -or $_ -match 'aad' -or $_ -match 'aae' -or $_ -match 'aaf' -or $_ -match 'aag'} | Measure-Object
#Matching for multiple strings

get-childitem -Path C:\ -Filter 'omega*' -R
#Search for a folder within windows file system

while ($zips = Get-ChildItem -Recurse -Filter *.zip) { foreach ($zip in $zips) {Expand-Archive -Verbose -Path $zip.FullName -DestinationPath $zip.DirectoryName -ErrorAction SilentlyContinue; if ($zips.Count -gt 1) { Remove-Item $zip.FullName -Force }}}
#A painful script that unzips all zipped folders within a zipped folder. Fails at the end, but CTRL+C to end the loop.

Get-ADGroupMember -Identity 'Domain Admins' -R | Measure-Object
# Total members of the Domain Admin group



```

