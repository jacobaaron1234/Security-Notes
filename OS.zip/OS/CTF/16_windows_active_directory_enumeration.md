```powershell
#From S-1-5-21-1004336348-1177238915-682003330-1000
#The domain portion is:
#21-1004336348-1177238915-682003330

Get-ADUser -Filter 'Name -like "*"' -Properties * | select Name,AccountExpirationDate 
# Displays user names and expiration dates
Search-ADAccount -AccountExpired | Where-Object { $_.Enabled -eq $true }
# More succinctly find accounts that are enabled and account is expired

Get-ADUser -Filter 'Name -like "*"' -Properties * | Select-Object mail,name | Where-Object {$_.mail -notlike '*.mil@mail.mil'}
# Searches for objects where the domain isn't .mil@mail.mil

Get-ChildItem -Path "Z:\" -R -Filter "*"
#Searches for everything. The file was obvious 

Get-ADUser -Filter 'Name -like "*"' -Properties OfficePhone, name | Select-Object OfficePhone, name
Karen.Nance

Get-ADUser -Filter 'Name -like "*"' -Properties * | select-object name,description | Where-Objec
t {$_.Description -notlike '*PLT Soldier' -and $_.Description -notlike 'Company*' -and $_.Description -notlike '*NCO'} 
# Filters out key words from descriptions of AD users


Get-ADUser -Filter 'Name -like "*"' -Properties * | select-object name,PasswordNeverExpires | Wh
ere-Object {$_.PasswordNeverExpires -eq 'True'}
#Finds users that has password never expires set to True

Get-ADUser -Filter 'Name -like "*"' -Properties * | select-object name,PasswordNeverExpires,Allo
wReversiblePasswordEncryption | Where-Object {$_.PasswordNeverExpires -eq 'True' -or $_.AllowReversiblePasswordEncryption -eq 'True'}
#Further shows the ReversiblePasswordEncryption AND users that PasswordNeverExpire

 Get-ADDomain | Select-Object name
 #provides short name
 
 Get-ADUser -Filter 'Name -like "*"' -Properties * | Select-Object name,SID | findstr /i krbtgt
 # Find RID (The last three digits of the SID) for krbtgt
 
Get-ADUser -Identity 'Karen.Nance' -Properties StreetAddress | Select-Object -ExpandProperty StreetAddress | ft -wrap
# address contains a ROT13 cipher 

Get-ADUser -Filter 'Name -like "*"' | findstr /i Tiffany
#Find user identified in cipher

#Anagram
mi
le
da
an
wis

damian.lewis


```

