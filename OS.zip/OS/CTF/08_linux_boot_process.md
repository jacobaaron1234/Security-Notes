```bash
dd if=mbroken bs=1 count=16 skip=446 | md5sum
# This will provide the md5sum of the first partition of a drive. 
# We use count=16 because the first partition size is 16 (See chart). We needed all 16.
# We skip 446 as that is the first, large part, of the drive.
# bs remains as 1 as a constant

dd if=mbroken bs=1 count=4 skip=392 | md5sum
# mbroken is our MDR drive, normally located at /dev/sda
# We count 4 because we wanted four characters "GRUB"
# We skip 392 (384 + 8) because we needed to skip all values up to "GRUB"

systemctl cat default.target
# Gives us the default target on the SystemD

#Grub uses "linux" to load the linux kernel

```

