# CCTC OS Playbook

[TOC]

## **Windows Powershell**

Generic

```powershell
findstr /i 'string'
#Looks for a string named string

Get-CimInstance -ClassName Win32_Service -filter "Name='NameofTheService'" | Select-Object Description
#find description of a service

Get-Content *file.txt* | Measure-Object
#Count the words within a document

Compare-Object (cat file1.txt) (cat file2.txt)
#compare two outputs in two files for differences 

get-childitem -Path C:\ -Filter 'omega*' -R
#Search for a file named omega and everything after omega, within windows file system

Get-Command -type cmdlet | Sort-Object -property noun | format-table -groupby noun 
#Sorts by property noun and formats the table to grouby noun

get-localuser | select Name,SID
#Selects Name and SID of all local users

Get-Help Get-Content
# Gets help for the cmdlet "Get-Content"
```

## Windows Powershell Profiles

Keywords:

- Profile
- Powershell / Startup
- Mention of PowerShell profile paths (see below)

<u>File Paths</u>

| All Users,All Hosts       | $PsHome\Profile.ps1                                          |
| ------------------------- | ------------------------------------------------------------ |
| All Users,Current Host    | $PsHome\Microsoft.PowerShell_profile.ps1                     |
| Current User,All Hosts    | $HOME\Documents\WindowsPowerShell\Profile.ps1                |
| Current User,Current Host | $HOME\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1 |

Steps:

1. Identify which profile is active and has been edited on the system. This can be run anywhere within PowerShell.

   ```powershell
   Test-Path -Path $profile.currentUsercurrentHost
   Test-Path -Path $profile.currentUserAllHosts
   Test-Path -Path $profile.AllUsersAllHosts
   Test-Path -Path $profile.AllUserscurrentHost
   ```

   Example TRUE output:

   ![image-20251112170142743](../Networking/Images/image-20251112170142743.png)

2. If **TRUE** for any of the profiles, take an additional look:

   ```powershell
   Get-Content -Path $profile.currentUsercurrentHost # This one would follow the example above
   Get-Content -Path $profile.currentUserAllHosts
   Get-Content -Path $profile.AllUsersAllHosts
   Get-Content -Path $profile.AllUserscurrentHost
   ```

   **There is likely either malicious code within a PowerShell Profile or hint to the flag.** Or the malicious Profile itself might be the flag. 

   

------



## Windows Registry

Keywords: 

- "Run every time the machine reboots"
- "Runs a single time, then deletes..."
- "Runs every time a user logs on"
- value
- Key
- "....plugged into this machine"
- User profile
- Wireless network

Steps:

1. In general, we'll follow the "3-Step" reading method to find our flag:
   1. Get-Childitem
   2. Get-ItemProperty
   3. Get-Item
2. Most likely, the flag is related to users logging in, machine reboots, or running a single time and then deleting. We'll walk through these processes. 

<u>**Runs every time the machine reboots**</u>
**By local machine:**

1. Run 

```powershell
# Run our sequence on the below key
# CHECK THE OUTPUT OF EACH ITEM. 
# SOME MAY COME UP EMPTY - THAT IS OKAY
Get-ChildItem HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run 
Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run 
Get-Item HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run 
```

2. Check for a flag.

------

<u>**Runs a single time, then deletes**</u>
**By local machine:** 

1. Run:

```powershell
# Run our sequence on the below key
# CHECK THE OUTPUT OF EACH ITEM. 
# SOME MAY COME UP EMPTY - THAT IS OKAY
Get-ChildItem HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
Get-Item HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
```

2. Check for a flag.

------

<u>**Runs every time a user logs on:**</u>

1. With *U*ser, *we may need to create* a PSdrive if there isn't one available. Try this out first:

```powershell
Get-Item 'REGISTRY::HKEY_USERS\*\Software\Microsoft\Windows\CurrentVersion\Run'
# This command will output for ALL users. Find the user the question is directed towards.
```

1a. OR, if you want to run for a specific individual:

```powershell
# First, grab the SID:
Get-Localuser | select Name, SID
```

2. Then, run the below commands but subsitutuing SID for the displayed SID for the correlating user:

```powershell
Get-ChildItem HKU:\SID\SOFTWARE\Microsoft\Windows\CurrentVersion\Run # CHANGE THE SID HERE
Get-ItemProperty HKU:\SID\SOFTWARE\Microsoft\Windows\CurrentVersion\Run # CHANGE THE SID HERE
Get-Item HKU:\SID\SOFTWARE\Microsoft\Windows\CurrentVersion\Run # CHANGE THE SID HERE
```



2a. **IF IT FAILS**, with error similar to "*A drive with the name 'HKU' does not exist*" **RUN:**

```powershell
New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS
```

Expected output:![image-20251112170229593](../Networking/Images/image-20251112170229593.png)

3. Now, re-run the commands above:

```powershell
Get-ChildItem HKU:\SID\SOFTWARE\Microsoft\Windows\CurrentVersion\Run # CHANGE THE SID HERE
Get-ItemProperty HKU:\SID\SOFTWARE\Microsoft\Windows\CurrentVersion\Run # CHANGE THE SID HERE
Get-Item HKU:\SID\SOFTWARE\Microsoft\Windows\CurrentVersion\Run # CHANGE THE SID HERE
```

4. Check for a flag. 

**EXAMPLE:** 

![image-20251112170252981](../Networking/Images/image-20251112170252981.png)

------

**Loads a single time when a user logs on**

This is the same as the "Runs every time a user logs on" section, but with "RunOnce" at the end rather "Run". Use more sepcific directions above with "RunOnce".

```powershell
Get-Item 'REGISTRY::HKEY_USERS\*\Software\Microsoft\Windows\CurrentVersion\RunOnce'
# This command will output for ALL users. Find the user the question is directed towards.
```

OR

```powershell
Get-ChildItem HKU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce 
Get-ItemProperty HKU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
Get-Item HKU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
```

If you recieve the, "*A drive with the name 'HKU' does not exist*" error, run the **New-PSDrive** command above. 

Check for a flag. 

**If you need a key from a location not listed above, Check out the Student guide, section 5.4*3

https://os.cybbh.io/public/os/latest/004_windows_registry/reg_fg.html#_5_registry_locations_of_interest



## Alternate Data Stream

Keywords:

- Hidden data

When dealing with Alternate Data Streams, the hardest part is identifying the file that has the alternate data stream. Within directories, where the test hopefully points out, we can do the below process to find one:

1. Locate the files with additional "streams" or hidden data:

```powershell
# Run the below to find any data stream within the -Path directory
# Change the -Path option to the file directory you are searching. 
# This command only outputs the hidden data stream
Get-ChildItem -Path C:\Users\CTF\Documents\ | Get-Item -Stream * | Where-Object {$_.Stream -notlike '*DATA'}

#This command will search the entire system for hidden data streams. 
Get-ChildItem -Path C:\ -Recursive | Get-Item -Stream * | Where-Object {$_.Stream -notlike '*DATA'}

#If you are a looking for a hidden file, use:
Get-ChildItem -Path -C:\Users\CTF\Documents\ -Hidden -Recursive

#OR/THEN

#Run the below on each file individually, assuming you know the location
Get-Item suspiciousfile.txt -Stream *
```

**Ignore outputs with Stream : $DATA**. Locate the file with an additional stream. In the example below, the alternate data stream is enclosed within **hidden**

![image-20251112170319502](../Networking/Images/image-20251112170319502.png)

2. Get the content of the alternate data stream:

```powershell
Get-Content alternatedatafile.txt -Stream alternatedata 

# Using the example above the command would look like this:
Get-Content nothing_here -Stream hidden
```

3. Find the flag

------

## Windows Auditing & Processes 

Keywords:

- Malicious process
- Service
- Strange activity

It was epmahsized that sysinternal tools are available during the exam!

1. Locate sysinternals and utilize the tools

```powershell
C:\path\to\sysinternal\tools\autoruns.exe
```

You'll be able to find most suspicious processes using **autoruns.** 

------



## **Linux Bash**

```bash
#Search for a file within the system
find / -name file 2>/dev/null

# Search for a string within the system (In this case, /home/student/)
grep -R 'string' /home/student/

#decrypt from aes-128
openssl enc -d -aes-128-cbc -in cipher -out decipher

wc -l file.txt && wc -l file.txt
#Finds wc with lines of mulitple files

cat /etc/passwd | cut -d ':' -f 1,7 | grep -v -e /usr/sbin/nologin
# Cuts the file, only shows the fields of 1 and 7, and removes a string "/usr/sbin/nologin"

sudo -u *username* ./executable
# use -u to run a file as someone else

cat paths | grep -Ff binlist.txt
# binlist.txt is the list of binaries from usr/bin. "ls /usr/bin > binlist.txt"
# We use -f for which file and -F for literal match (no regex)
```



## Linux Boot Process

Keywords:

- Malicious process
- Service
- Strange activity
- Boot
- Kernel

Regarding the Linux boot process, we need to look in key file locations that are related to the boot process for flags. 

1. Check the below:

```bash
# Grub CFG. This will have the location of the kernel (The file after the "Linux" command)
cat /boot/grub/grub.cfg
```

2. Identify if SysV or SystemD

```bash
ls -l /sbin/init
# SystemD will have a symbolic link to systemd (example below)
```

![image-20251112171229990](../Networking/Images/image-20251112171229990.png)

**SysV**

1. Check the below:

```bash
cat /etc/inittab
ls -l /etc/rc0.d
ls -l /etc/rc1.d
ls -l /etc/rc2.d
ls -l /etc/rc3.d
ls -l /etc/rc4.d
ls -l /etc/rc5.d

# Check every one for anything suspicuios!
```

Example output of one directory:
![image-20251112171310807](../Networking/Images/image-20251112171310807.png)

There may be malicious links/scripts here! The text in GREEN is what is being run. Make sure you look into anything suspicoius:

```bash
cat /etc/init.d/suspicious
```



**SystemD** 

1. Identify/verify the default.target

```bash
ls -l /lib/systemd/system/default.target
```

![image-20251112171406850](../Networking/Images/image-20251112171406850.png)

2. Check contents of default.target. Look for anything suspicious. If symbolically linked like the example above, cat that file instead. 

```bash
systemctl cat default.target
systemctl list-dependencies default.target  #Run both. This will show you anything related to default.target
```

3. Take a look at all services for anything suspicously named services

```bash
systemctl list-units --type=service
```

4. When in doubt, take a look and comb through all running services and dependencies

```bash
systemctl # Just run this for the full overview
```



------



## Linux Auditing & Process [ALSO CHECK - LINUX BOOT PROCESS]

**Services also can be started within the boot process**

Keywords:

- Malicious process
- Service
- Strange activity
- Strange port

Initially run these to check for anything in CronJobs:

```bash
cat /etc/crontab
crontab -l -u *username* 
```

If here...free chicken

If not:

**Identifying**

There's not much of a 'short' way to find malicious processes. First, we look through our processes looking at ps -elf and htop:

1. View snapshot of current processes

```bash
ps -elf
```

If you're lucky, or if the process is continuously running, you'll see it here. 

1a. If the question is asking for the parent process of a malicious process, it's better if we run the forest version of the command:

```bash
ps -elf --forest # Provides a nice visual 
```

2. We can also potentially see processes from identifying suspicious ports:

```bash
ss -ntlp
```

![image-20251112174236015](../Networking/Images/image-20251112174236015.png)

3. If you unfortunately have to wait for a process to start, use htop or top:

```bash
htop
top
```

and then wait for bad things to happen

**Finding the Source**

We typically use two commands to find the source of the processes via PID.

1. Use lsof

```bash
sudo lsof -p PID # Sub PID for the PID number. In the example above, it would be 554132
```

2. Use /proc/

```bash
sudo ls -l /proc/554132 #Using the example above. Sub the number for the PID
```

You will see symbolic links in here that show the path to what started the process. 



**Also Check**

```bash
cat ~/.bash_logout
cat /etc/profile
```

