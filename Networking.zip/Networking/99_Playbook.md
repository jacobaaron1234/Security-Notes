# Network Playbook

<u>NOTE: Most commands use example credentials and files. CHANGE TO YOUR REQUIRED USE.</u> 

[TOC]

## Router Reconnaissance - [NO ROUTERS ON TEST - DO NOT USE]

Network reconnaissance will be key to the exam and can be followed in a systematic process. First, we connect to our "entry float IP" or initial host machine to conduct the scans. From there, we enumerate the network with available networking information (most likely a network with a subnet, e.g., 172.168.5.1/27). Once we find available open ports, we investigate further by either banner grabbing, pulling website information, or directly connecting to the host. 

**CREATE A NETWORK MAP AS WE PROGRESS THROUGH A NETWORK. ALWAYS.** 

**Basic enumeration** 

<u>STEPS</u>

1. **Connect to your "entry float IP"** or initial host machine with provided credentials. This IP or system will be given to you. **Generally, all scans will be conducted here**. At times, you may need to enumerate from a target machine on a network. 
   *If your entry float IP is your within initial box, no need to connect further*

Entry Float IP given for scenario below: 10.50.189.76

**Command:**

```bash
ssh -X username@float_ip_address #CHANGE ME!
# Use the -X here just in case we have to deal with images. 
```

![Untitled](Images/Untitled.png)
*Notice the change in hostname as we move into a new box.* 

2. **Enumerate a given IP or IP/Subnet with nmap**. This step falls under the assumption you are given an IP or Target to enumerate. 

Given Target 1 IP: 172.16.120.1

**Command:**

```bash
nmap target_ip_address
# In most cases, the default nmap scan is fine. 
 
nmap -sU target_ip_address # If UDP is specified, use -sU within your command.
nmap target_ip_address/subnet # (e.g., nmap 172.16.1.1/24) if scanning a whole network
nmap target_ip_address -p 80,100-200  # for a custom port range. You can either put single ports, range, or both
```

![Untitled1](Images/Untitled1.png)
*ssh is a key port. We don't mess with bgp.*

3. **Connect to the target with ssh.**

**Command:**

```
ssh username@target_ip_address
```

![Untitled2](Images/Untitled2.png)
*Note the "Welcome to VyOS" message that lets us know this is a router.* 
*In this case, we preemptively used "vyos" as the username as a guess*

4. **Enumerate the router** for network information 

**Command:**

```bash
show int
```

![Untitled3](Images/Untitled3.png)
*If you ssh to any of the IPs within the interface list, **you will ssh back into the same router***

5. Repeat steps 2-4 as needed. From here, your network starts to branch out. 

NOTE: 

- Credentials may change per system you ssh or connect to. 
- You will likely encounter more regular Linux boxes than routers.
- Be sure to map your network as you enumerate!

**HTTP/80 Open**

If you see HTTP or port 80 open on an host, do the right thing and wget that thang. 

![Untitled4](Images/Untitled4.png)
found one!

<u>STEPS</u>

1. **Download the webserver files** to your current directory

```bash
wget -r target_host_ip # In this course, always use -r
wget -r target_host_ip:port  # If port is not conventional 
```

![image-20251121203316317](Images/image-20251121203316317.png)

2. **List directories and cd into the new folder**. wget -r will download all files to folder within your current working directory

```bash
ls
cd directory_ip_name
```

![image-20251121203440104](Images/image-20251121203440104.png)

3. Profit

```bash
eog hint-01.png # To open images. If fails, check to make sure you added -X on your ssh command
```

NOTE:

- Webserver files can have key information like user/password (credentials) or additional networking info. Or useful hints like the picture above. 

### Banner Grab

We use banner grabbing to identify service information on a port, and also to potentially receive a response from the service. 

STEPS

1. **Connect to the port** using netcat

**Command:**

```bash
# For TCP (most ports)
nc target_ip_address port # e.g., nc 172.16.1.1 2000

# For UDP (some ports)
nc -u target_ip_address port # e.g., nc 172.16.1.1 2020
```

![image-20251121204744521](Images/image-20251121204744521.png)
*Potentially a flag or spicy info here!*

2. **Profit**

------

## Network Enumeration 

[TOC]

Enumerating a network can be a done through a methodical process. First, we scan our initial target to discover any open ports. Then, we pull information from those open ports. Next, we decide what tunnel to create, if needed. After any necessary tunnels (if any), we connect to the target and enumerate it further with a Dynamic tunnel to discover our next-target to enumerate. This process is repeated, but tunnel creation extends the duration of enumeration. 

STEPS:

1. **Scan the initial target**. Identify any open ports. 

**Command:**

```bash
./scan.sh

# OR 

nmap ip_address
nmap ip_address/CIDR # You can also scan the full subnet by adding the CIDR within a nmap command
```

![image-20251205215625063](Images/image-20251205215625063.png)

  1a. Update network map with new information:  

![image-20251206085614890](Images/image-20251206085614890.png)

2. Pull information from open ports.

**Command:**

### HTTP - wget

```bash
# HTTP
wget -r 10.50.93.47 # By default wget will use port 80
wget -r 10.50.93.47:8080 # Example command to modify which port to use (HTTP)
```

### FTP - wget

```bash
# FTP (Not used in this example)
wget -r ftp://10.50.93.47 # Uses the anonymous login to pull available files 
```

In this example we only see port 80:

![image-20251206085157624](Images/image-20251206085157624.png)

**The initial files downloaded will contain important hints or even flags.** 

  2a. View downloaded files. 

**Command:**

```bash
ls # Find the directory you just downloaded that contains webserver information/files
cd target_ip # The directory you just downloaded
eog filename.png # Take a look at any images
```

![image-20251206085408692](Images/image-20251206085408692.png)

  2b. Update network map with new information. 

![image-20251206085736401](Images/image-20251206085736401.png)

3. **Connect and further enumerate to the target** host. We've enumerated what we can through port 80 in this example. Our next step is to jump into the box to identifiy a new target network and check common directories for flags/hints (/usr/share/cctc). 

**Command:**

```bash
ssh Sterling@10.50.93.47 # Uses the username we just found and public IP available to us
```

![image-20251206090524234](Images/image-20251206090524234.png)

  3a. **Enumerate the host internally** to find additional information. 

**Command:**

```bash
ip addr # Displays interface IP information
ip -br -c addr # Displays a summary of the interface IP information (with color!)

ls /usr/share/cctc # Known directory location of hints/flags 

ss -plnt # Show port information. 
# Pertinent to us are ports that are preceded by 0.0.0.0, e.g., 0.0.0.0:80. This means the port/service is running on this system. 
```

![image-20251206091231113](Images/image-20251206091231113.png)

Key information identified! Nothing new identified within port information. We exclude items with 127.0.0.1 preceding. The ip address found is an unknown private network, something we can use to further enumerate. 

3b. **Download identified hint/flag** from key directory and **view**. 

Command:

```bash
# IN A NEW TERMINAL ON YOUR OWN HOST BOX
scp username@ip_address:/usr/share/cctc/target.png .

eog target.png # View the file!
```

![image-20251206091646526](Images/image-20251206091646526.png)

  3c. Take a moment to update your network map with the new IP identified within host Sterling. 

![image-20251206091858757](Images/image-20251206091858757.png)

4. **Enumerate the new identified network**. At this point, we've cleared this box of flags. We move to enumerate further. We need to **build a Dynamic Tunnel** and utilize **Proxychains** to do this, as we cannot see anything past host Sterling from our own host machine. 

**Command:**

```bash
# First, create the tunnel
ssh Sterling@10.50.93.47 -D 9050 -NT 

# Enumerate using proxychains
proxychains ./scan.sh 
```

![image-20251206093002580](Images/image-20251206093002580.png)

New information discovered!

  4a. **Update the network map** with new information. 

![image-20251206093125709](Images/image-20251206093125709.png)

4b. Repeat step 2, but utilizing proxychains. Download files from 21 (FTP) and 80 (HTTP). We use proxychains as we're currently masquarding as host Sterling, and Sterling is the only host that has access to the next target via the connected network(s). 

**Command:**

```bash
proxychains wget -r 10.1.2.200
proxychains wget -r ftp://10.1.2.200
```

View downloaded files to find more hints/flags. 

![image-20251206093735638](Images/image-20251206093735638.png)

  4c. Update network map with new information. 

![image-20251206100709594](Images/image-20251206100709594.png)

  4d. BONUS - Connect to the FTP server to download files. 

### FTP Server Connection Example

Command:

```bash
proxychains ftp 10.1.2.200
Lana / password # Credentials of the box
passive # Enter passive mode enabling you to run commands
ls /usr/share/cctc/
cd /usr/share/cctc/
get filename.png # Downloads the file in the current directory
```

![image-20251206094758732](Images/image-20251206094758732.png)

![image-20251206094440689](Images/image-20251206094440689.png)

At this point, we've discovered all information we can from external reconnissance, using proxychains. Now, we have to connect to the system. Unfortunately, we do not have a ssh port open. In this case, we'll need to build a Local Tunnel to bind Lana's telnet port, 23, to our local machine, giving us access to telnet from our host machine (In this case - Blue internet host).

Utilize the steps below, within "SSH Tunneling - Local Port Forward (-L) - Single Hop", to further connect and enumerate this network. This "Network Enumeration" process is repeated per system, once tunnels are built. 

------

## SSH Tunneling - Local Port Forward (-L) - Single Hop

[TOC]

Local port forwarding **will be the predominate tunneling method** during the test and during CCTC-Security. We use local port forwarding to further 'dive' or ssh into multiple networks. 

![image-20251201095747815](Images/image-20251201095747815.png)

For example, Blue Internet Host (Your first box) cannot ssh or enumerate past host Bender. We use SSH Tunneling, between a dynamic and local port forward method, in order to enumerate to Box Philip. 

<u>STEPS</u>

1. **Enumerate the target network**. If you do not recieve a target IP, use networks found on your own box. 

Example TARGET IP: 10.50.223.74

**Command:**

```bash
./scan.sh # Input IP parameters in scan.sh script

# OR 

nmap 10.50.223.74
```

![image-20251201100243997](Images/image-20251201100243997.png)

  1a. **Download web server files** (if available). The webserver may also be on a different port than 80. Default is 80. 

```bash
wget -r 10.50.223.74 # Uses default port of 80
```

![image-20251201101506703](Images/image-20251201101506703.png)

**Look at all files within the webserver.** In this case, we found the next host username of **Bender** after looking at some files. 

2. **Identify SSH port.** During the next hop, *SSH or Telnet* **WILL** be available. If you do not see it in your scan, either increase your port range, or identify an odd port that may be the ssh service in disguise. In this case, we identify an odd port by banner grabbing:

**Command:**

```bash
nc 10.50.223.74 1234 # Banner Grab
```

![image-20251201100725079](Images/image-20251201100725079.png)

3. **SSH to Target.** We need to identify our next target. We do this by enumerating the current target **internally**. 

![image-20251201102054770](Images/image-20251201102054770.png)

  3a. **Find the next network.** Most of the time, you'll find the next-hop network by running an ip addr and looking for an additional ethernet interface. 

**Command:**

```bash
ip addr # Try this first
ip neigh # Try this next
```

![image-20251201102430176](Images/image-20251201102430176.png)

4. **Enumerate** discovered network using **Proxchains**. We **have to use proxychains** here as we cannot enumerate this network (172.17.17.17/28) from our Blue Internet Host. We need to masquarde ourselves as "Bender" in order to identify the hosts on this network, using a **Dynamic Tunnel**, as he is the only host that can see other hosts in that network. 

  4a. **Setup the Dynamic Tunnel**

**Command:**

```bash
ssh Bender@10.50.223.74 -p 1234 -D 9050 -NT
# The -D 9050 is our Dynamic tunnel portion of this command
# The -p 1234 comes from the port we know to be the ssh service
# We use the public IP address instead of localhost here as we have not created a -L tunnel yet. 
```

  4b. **Proxychain scan it**

**Command:**

```bash
proxychains ./scan.sh
# Only use the subnet that we identified earlier (/28)

proxychains nmap  172.17.17.17/28
```

![image-20251201104941752](Images/image-20251201104941752.png)

**New IP identified!** Note that 172.17.17.17 was our IP from Bender. We found the below on 172.17.17.28:

- 23 (telnet)
- 21 (ftp)
- 80 (http)

Unfortunately, we do not see an SSH port here, but we DO see a telnet service running. We can use that, and to do so, we create a **Local Port Forward to the service.** 

5. **Create the Local Port Forward (-L)** tunnel

**Command:**

```bash
ssh Bender@10.50.223.74 -p 1234 -L 1111:172.17.17.28:23 -NT
# We use 'Bender@10.50.223.74' because this is the host that has access to the 172.17.17.28 host. 
# We use -p 1234 as this was the SSH port open on Bender
# -L designates the local port forward
# 1111 is a port created by our preference, that binds the target to our Blue Internet Host
# 172.17.17.28:23 is the IP address and port we are targeting
```

![image-20251201111227041](Images/image-20251201111227041.png)

*We verified the tunnel was created on Blue Internet Host by using 'ss -plant | grep 1111'*

6. **Connect over the tunnel to the new target**. In this case we use telnet, but more commonly we use ssh. 

We can now connect to the **NEW** target host of **172.17.17.28** **over Telnet**!

```bash
telnet localhost 1111
# We use localhost here as we authenticate to ourselves over a desginated local port (from our created tunnel). Think Localhost & Local Port
# 1111 is the local port we created from our -L command in step 5
# Telnet might take 15 seconds or so

#IF WE HAD SSH OPEN AND HAD BOUND OUR LOCAL TUNNEL TO SSH
ssh Bender@localhost -p 1111
```

![image-20251201112113997](Images/image-20251201112113997.png)

**Success!**

Note - The Dynamic Tunnel is not required to use Telnet here. It could be closed, but left open in the terminal as we may need it. 

For reference, here's what happens if you **break the tunnel and try to telnet:** 

![image-20251201122829718](Images/image-20251201122829718.png)

------

## SSH Tunneling - Remote Port Forward (-R)

[TOC]

Remote port forwarding is done to make a port (typically ssh), that is available INTERNAL to a system, EXTERNAL to it - making it available to us. While within the box that has an internal SSH port available, we connect to the previous box and assign a port ON THE PEVIOUS BOX to the internal port that is hosting SSH. 

**<u>KEY INDICATOR</u>:** IF YOU SEE **TELNET AND NO SSH SERVICE**, YOU MOST LIKELY NEED TO CREATE A REMOTE TUNNEL. 

![image-20251201174402377](Images/image-20251201174402377.png)

Notice in the network map above, **Philip does not have port 22 available** and it's not on a higher port (Identified through some throrough scanning). We will need to remotely assign his internal ssh port to the Bender so we can then create a Local Port Forward to the newly created port on Bender, which is associated with Philip's internal SSH. 

**Background:**

We currently have a local port configured to connect to Philip's telnet, which allows us to telnet to Philip. 

![image-20251201180952394](Images/image-20251201180952394.png)

STEPS:

1. **Identify the internal SSH service**. This service may be on a different port, other than pot 22 (default ssh). 

**Commands:**

```bash
ss -plant 
cat /etc/ssh/sshd_config | grep Port #Gives back the port configured for ssh. 
```

**Note** - "0.0.0.0:PORT" is an indicator of a port native to that system. 

![image-20251201191159935](Images/image-20251201191159935.png)

![image-20251201191103216](Images/image-20251201191103216.png)

2. **Create the Remote Port Forward (-R)**. 

```bash
ssh Bender@172.17.17.17 -p 1234 -R 10400:localhost:4321 -NT
# We use 'Bender@172.17.17.17' because we connect BACK to the host we (Blue Internet Host) has access to via ssh. Note we use the interal IP not the public IP in this case. The internal IP is routable to Philip. Public is not. 

# We use -p 1234 as this was the port on Bender that had ssh available. 

# We use the -R to desginate the Remote Port Forward

# The 1XX00 is the custom port we create based on our seat number. (e.g., 10101, 10102, 10103 for Seat 1)

# We use localhost:4321 because as we are running this command from Philip, we're identifing to use itself as the IP. 4321 is located on the localhost - so to say. 4321 is the port we found ssh on within Philip. 
```

![image-20251201194839105](Images/image-20251201194839105.png)

  2a. Verify we can see the newly added port on Bender:

**Command:**

```bash
ssh Bender@10.50.223.74 -p 1234 # On blue internet host. Change port (-p) as needed or leave blank for default
ss -plant | grep 10X00 # On bender
```

![image-20251201195454484](Images/image-20251201195454484.png)

This port (10400) has a connection to Philip's ssh port (4321)

3. **Create a Local Port Forward** tunnel connecting the newly created Remote Port (Which has a binding to Philip's ssh) to your own (Blue Internet Host) local port. 

**Command:**

```bash
ssh Bender@10.50.223.74 -p 1234 -L 2222:localhost:10400 -NT
# We use 'Bender@10.50.223.74' to connect to Bender in order to bind a port this host has. The public IP is used over interal as this is what Blue Internet Host can see. 

# We use -p 1234 as this is hosting the ssh service on Bender

# We use -L to distinguish using a Local Port Forward

# 2222 is the port we're creating on our local machine associated with the following binding

# localhost:10400 is used as we're binding Bender's (localhost in his sense) port 10400. Port 10400 is the one we created with the remote port forward.
```

![image-20251202081506849](Images/image-20251202081506849.png)

  3a. **SSH to Philip** to verify your tunnels

```bash
ssh Philip@localhost -p 2222
# We use 'Philip@localhost' as we now need to authenticate over Blue Internet Host's (localhost) internal port that we've created. 

# -p 2222 is the port we created with our Local Port Forward
```

![image-20251202082619403](Images/image-20251202082619403.png)

**Success!**

------

## SSH Tunneling - Local Port Forward (-L) - Multiple Hops

[TOC]

Local port forwarding may need to be done in sequence. In which case, we need to use previous tunnels built to authenticate further into the network to enumerate the network further. 

![image-20251205172637689](Images/image-20251205172637689.png)

**Background:**

Previously, we had created a local tunnel binding Philip's Telnet port (23), to enable us to access the device via Telnet. From there, we created a *remote port forward* to build a tunnel to Bender, remotely adding a port *to* Bender *from* Philip which contained the target of Philip's (localhost - in Philip's sense) of 4321 (ssh). Now, we need to enumerate further into the network to identify the next host. 

![image-20251205172919468](Images/image-20251205172919468.png)

STEPS:

1. **Enumerate the next target.** Using the local tunnel we've built, we can build a dynamic tunnel to enumerate the next host. 

```bash
ssh Philip@localhost -p 2222 -D 9050 -NT
# -p 2222 as this is the local port we assigned to Philip's SSH information (IP:PORT) from a prior local tunnel
```

![image-20251205161252532](Images/image-20251205161252532.png)

  1a. **Scan the identified network.** The network was identified in a prior step - 192.168.30.130/26. 

```bash
proxychains ./scan.sh
```

![image-20251205162135352](Images/image-20251205162135352.png)

  1b. **Pull down the new files** with proxychains. **Continue to enumerate the network**. 

```bash
proxychains wget -r 192.168.30.150
proxychains wget -r ftp://192.168.30.150
```

![image-20251205162628059](Images/image-20251205162628059.png)

A hint provided more information regarding the username and a SSH port available at a higher port number. Let's re-scan at a higher interval to discover it. 

```bash
proxychains ./scan.sh
```

![image-20251205163039624](Images/image-20251205163039624.png)

Banner grab to confirm SSH:

```bash
proxychains nc 192.168.30.150 1212
```

![image-20251205163135418](Images/image-20251205163135418.png)

Updated network map:

![image-20251205165826442](Images/image-20251205165826442.png)

2. **Create a local tunnel** to next target using previously created tunnels.

```bash
ssh Philip@localhost -p 2222 -L 3333:192.168.30.150:1212 -NT
# We use localhost here as we're connecting through a local tunnel. Local tunnel local host!
# -p 2222 as this is the local port we assigned to Philip's SSH information (IP:PORT) from a prior local tunnel. We need to use Philip here as he is the host adjacent/has access to Leela. 
# We're using -L to distinguish a local tunnel
# '192.168.30.150:1212' is the targeted network that we're binding to 3333
```

![image-20251205171302770](Images/image-20251205171302770.png)

3. **SSH to next target** to confirm. 

```bash
ssh Leela@localhost -p 3333
```

![image-20251205171449408](Images/image-20251205171449408.png)

**Success!**

------

## Secure Copy Protocol  (SCP)

[TOC]

We will likely need to use the secure copy protocol (scp) in order to pull files to our own machine during the exam. 

Most likely - the file is located within **/usr/share/cctc**. 

### Normal SCP

STEPS:

1. Pull a file to your system

**Command:**

```bash
# Pulling a file to your system
scp tgt_username@tgt_ip_address:/path/to/file/flag.txt . # Don't forget the period!

# ! Example with /usr/share/cctc !
scp tgt_username@tgt_ip_address:/usr/share/cctc/* . 
```

![image-20251205213831654](Images/image-20251205213831654.png)

  1a. Send a file to another system 

**Command:**

```bash
# Sending a file to another system
scp /path/to/file/flag.txt tgt_username@tgt_ip_address:/path/to/drop/location
```

![image-20251205214034539](Images/image-20251205214034539.png)

### Using SCP with a Local Tunnel

STEPS:

**Command:**

```bash
scp -P 1111 Aang@localhost:/usr/share/cctc/Aang-share.png . # Don't forget the period!
# -P 1111 is from the local tunnel we've built to connect to host Aang

scp -P Local_Tunnel_Port tgt@tgt_ip_address:/path/to/tgt/file.txt . 
```

![image-20251205214207068](Images/image-20251205214207068.png)
