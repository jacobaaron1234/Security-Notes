# Day 5 - Network Reconnaissance

[TOC]

## Basic Commands - Passive

### dig

Provides DNS info of a domain

```bash
dig uwcu.org
```

![image-20251120153711806](Images/image-20251120153711806.png)

### whois

Provides public information of a domain

```bash
whois uwcu.org
```

![image-20251120153822989](Images/image-20251120153822989.png)

## Basic Commands - Active Internal

### banner grab

Use this to identify service running on an IP

```bash
nc 10.10.0.40 22 # Banner grabs ssh on 10.10.0.40
```

### ping sweep

Used to identify hosts on a connected network

```bash
for i in {1..254}; do (ping -c 1 172.16.82.$i | grep "bytes from" &) ; done
```

![image-20251120154213632](Images/image-20251120154213632.png)

### nmap

Network scanning tool.

- TCP Full Connect Scan (-sT) is the user default
- TCP SYN Scan (-sS) is the root default

```bash
# Some default scans
nmap 172.168.82.106/27 -v # Verbose default scan

nmap 172.168.82.106/27 -Pn --open # Disable the ping sweet, and only show open ports
```

#### options

```bash
-sS SYN scan # Stealth scan - Only sends SYN packets for less traffic generation

-sT Full connect scan # Will establish a full tcp handshake

-sN Null scan # TCP flags are set to 0

-sF FIN scan # TCP flag to FIN only

-sX XMAS tree scan

-sU - UDP scan

-sI - Idle scan 

-PE - ICMP Ping

-Pn - No Ping

-PP - Timestamp Discovery Probe

-PM - Netmask Request Discovery Probe
```

#### scan types

```bash
-D Decoy scan 

-sA ACK/Window scan 

-sR RPC scan 

-b FTP scan 

-O OS fingerprinting scan 

-sV Version scan 

-sM Maimon scan
```

### netcat - scanning

Another way to scan

```bash
nc [options] [Target IP] [Target Port(s)]

netcat -nzvw1 [TARGET IP] 1-1023 #Scans a range of ports for target IP

netcat -nzvw1 [TARGET IP] 21-23 25 80 443 #Scans a set amount of ports
```

![image-20251121084600876](Images/image-20251121084600876.png)

Script:

```bash
wget https://git.cybbh.space/cted/tech-college/cttsb/cctc/net/Net/-/raw/main/Resources/scan.sh

chmod u+x scan.sh
```

### wget

Used to download files from a web server

```bash
wget 172.16.1.15 #Downloads the initial webpage from 172.16.1.15

wget -r 172.16.1.15 #Downloads all files witin the webserver
```

![image-20251121092647118](Images/image-20251121092647118.png)

## Key Locations

### DNS Config

```bash
/etc/resolv.conf
```

### ARP Cache

```bash
ip neighbor
```

### Network Connections

```bash
ss -ntlp
```

### Services File

```bash
/etc/services
```

### Routing Table

```bash
show ip route # Linux
route print # Windows
```

### Local Share Drive (CCTC)

```bash
ls -al /usr/share/cctc
```

### SSH Config

```bash
/etc/ssh/sshd_config
```

