# Day  - SSH Tunneling and Covert Channels

[TOC]

I am - 104XX

## Local Port Forward

Local port binding - One hop. 

```bash
# First, we verify our next-hop host has access to our target host. See middle terminal
ssh student@172.16.82.106
ip addr

# Then, we create a ssh local port binding to our target's ssh port. 
ssh student@172.16.82.106 -L 4444:192.168.1.10:22 -NT

# Lastly, we connect to the port we bound to our localhost. This port is bound to our target. We should ssh into a target. 
ssh localhost -p 4444
```

![image-20251124133518840](Images/image-20251124133518840.png)

## Forward Through Tunnel (2 Hops)

```bash
ssh student@172.16.1.15 -L 2222:172.16.40.10:22
ssh student@localhost -p 2222 -L 3333:172.16.82.106:22

#Lastly, connect to 172.16.82.106
ssh student@localhost -p 3333
```

![image-20251124142354498](Images/image-20251124142354498.png)

## Remote Port Forward

Remote port forwarding is a feature of SSH that allows you to securely expose a port on a remote server and forward incoming connections to that port to a local machine or another remote machine via the client that issued the command.

```bash
# On pivot host
ssh student@10.10.0.40 -R 4444:localhost:22 -NT

# On blue internet host
ssh student@localhost -p 4444
```

![image-20251124172107098](Images/image-20251124172107098.png)

## Dynamic Port Forwarding through a Tunnel

Dynamic port forwarding through a previously established port forward involves creating a nested SSH tunnel to extend the reach of dynamic port forwarding to a remote target accessible through an intermediate server.

```bash
# On blue internet host
ssh student@172.16.1.15 -L 2222:172.16.40.10:22 -NT

# On blue internet (localhost) host
ssh student@localhost -p 2222 -D 9050 -NT

# use proxychains to utilize the -D tunnel
proxychains nmap -Pn -sT 172.16.82.96/27 -p 21-23,80
```

![image-20251124174608091](Images/image-20251124174608091.png)

## Tunnels Practice

Entry Float IP: 10.50.63.101

### Initial Scan & Banner Grab

```bash
nmap 10.50.63.101 -p 21,22,23,80
nc 10.50.63.101 22
nc 10.50.63.101 80
GET /
```

![image-20251125083921731](Images/image-20251125083921731.png)

Banner grab port 80, with using GET / to prompt the web server

![image-20251125084043346](Images/image-20251125084043346.png)

### wget server

![image-20251125084234501](Images/image-20251125084234501.png)

### ssh in

```bash
ssh john@10.50.63.101
#password is password
```

### Internal Recon

```
ip addr
ip neigh
ip route
```

![image-20251125084800373](Images/image-20251125084800373.png)

### Pull File

Found in /usr/share/cctc/john.png

```bash
scp john@10.50.63.101:/usr/share/cctc/john.png .
```

![image-20251125085605503](Images/image-20251125085605503.png)

### Enumerate using Dynamic Tunnel

```bash
ssh -D 9050 john@10.50.63.101 -NT
proxychains nmap 10.50.63.101/27 -Pn --open

# OR

proxychains ./scan.sh
```

![image-20251125090708944](Images/image-20251125090708944.png)

### Enumerate new ports

We identified a new IP at 104.16.181.15

```bash
proxychains nc 104.16.181.15 22
proxychains nc 104.16.181.15 80
proxychains nc 104.16.181.15 21
```

![image-20251125091223375](Images/image-20251125091223375.png)

### Pull information from new ports

```bash
proxychains wget -r 104.16.181.15
proxychains wget -r ftp://104.16.181.15
```

![image-20251125091513488](Images/image-20251125091513488.png)

### Setup -L Forward

```bash
ssh john@10.50.63.101 -L 1111:104.16.181.15:22 -NT # In one terminal on Blue-Internet-Host

ssh jack@localhost -p 1111 # In another terminal on Blue Internet-Host
```

![image-20251125094355594](Images/image-20251125094355594.png)
![image-20251125094721085](Images/image-20251125094721085.png)

### Setup-D-Forward

```bash
ssh jack@localhost -p 1111 -D 9050 -NT
```

![image-20251125094850300](Images/image-20251125094850300.png)

### Enumerate new host

```bash
ip a #Identify new network

#look in
ls /usr/share/cctc

#grab image
proxychains scp jack@localhost:/usr/share/cctc/jack.png .

#Scan it
proxychains nmap 142.16.8.55/27 -p 21-23,80 --open
```

![image-20251125095011487](Images/image-20251125095011487.png)

### Tunnel update

So far we look like this:

![image-20251125102122651](Images/image-20251125102122651.png)

With two Local Tunnels we have accessed a third pivot point (Bill). We've created a dynamic tunnel to Bill so we can enumerate further. 
