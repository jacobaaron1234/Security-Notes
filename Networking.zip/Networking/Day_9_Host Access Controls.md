# Day 9 - Host Access Controls

[TOC]

## IPtables

### List table (filter)

```bash
sudo iptables -L
sudo iptables -t nat -L # Shows nat table
sudo iptables -t mangle -L # Shows mangle table
```

![image-20251202132509002](Images/image-20251202132509002.png)

### Adding rules

```bash
sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT # Allows others to SSH in to my host
sudo iptables -A OUTPUT -p tcp --sport 22 -j ACCEPT # Allows traffic to ssh back from us (source)

sudo iptables -A OUTPUT -p tcp --dport 22 -j ACCEPT # Allows us to ssh out
sudo iptables -A INPUT -p tcp --sport 22 -j ACCEPT # Allows others to ssh traffic back in

sudo iptables -A INPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT
sudo iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT
sudo iptables -A INPUT -p tcp -m multiport --ports 22,23,3389 -j ACCEPT
sudo iptables -A OUTPUT -p tcp -m multiport --ports 22,23,3389 -j ACCEPT

```

![image-20251202133304073](Images/image-20251202133304073.png)

![image-20251202133448300](Images/image-20251202133448300.png)

### Apply the policy

```bash
sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT DROP
```

![image-20251202134405603](Images/image-20251202134405603.png)

### Delete the policy

First we need to change the policy back to the ACCEPT. If we leave it at DROP, everything will be dropped by default. 

```bash
sudo iptables -P INPUT ACCEPT
sudo iptables -P OUTPUT ACCEPT
sudo iptables -P FORWARD ACCEPT
sudo iptables -F
```

![image-20251202135831058](Images/image-20251202135831058.png)

### Mangle

```bash
iptables -t mangle -A POSTROUTING -o eth0 -j TTL --ttl-set 128 # Set the TTL from eth0 to 128
iptables -t mangle -A POSTROUTING -o eth0 -j DSCP --set-dscp 26 # Set the DSCP from eth0 to 26
```



## nftables

```bash
sudo nft list ruleset # Display any nft tables
```

![image-20251202134633401](Images/image-20251202134633401.png)

### Create a table

```bash
sudo nft add table ip cctc
```

![image-20251202134735666](Images/image-20251202134735666.png)

### Create the base chain

```bash
sudo nft add chain ip cctc input { type filter hook input priority 0 \; policy accept \; }
sudo nft add chain ip cctc output { type filter hook output priority 0 \; policy accept \; }
# Input and output chain
```

![image-20251202135154601](Images/image-20251202135154601.png)

### Add a rule

```bash
sudo nft add rule ip cctc input tcp dport 22 accept
sudo nft add rule ip cctc output tcp sport 22 accept 
# Accept ssh from both ends
```

![image-20251202135402311](Images/image-20251202135402311.png)

### Apply the chain

```bash
sudo nft add chain ip CCTC INPUT { \; policy drop \; }
sudo nft add chain ip CCTC OUTPUT { \; policy drop \; }
```

![image-20251202135523168](Images/image-20251202135523168.png)

### Delete table

```bash
sudo nft delete table ip cctc
```

