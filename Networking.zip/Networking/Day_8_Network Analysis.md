# Day 8 - Network Analysis

More in-depth Wireshark analysis. 

```bash
# Handy Wireshark Filters
ip contains "This program" #Identifies files that are masquarading as a MZ or executable. 
```

![image-20251201131803037](Images/image-20251201131803037.png)

Identfied the file with the odd mz:

![image-20251201131855756](Images/image-20251201131855756.png)

Find file in HTTP Object list:

![image-20251201131958701](Images/image-20251201131958701.png)

Download or Save. 

File for more information and take the sha256 hash to VirusTotal to identify malicious file:

![image-20251201132213307](Images/image-20251201132213307.png)

![image-20251201132317789](Images/image-20251201132317789.png)