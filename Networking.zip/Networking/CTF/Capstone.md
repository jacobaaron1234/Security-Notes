```bash
10.50.134.55 (22, 80)
FLAG: crowning achievement

Capstone v2 02
02 PCAP 1
tcpdump -n -r capstone-bpf.pcap "ip[1] >> 2 = 26 && ip[16:4]=0x0A000067 " | wc -l

02 PCAP 2
tcpdump -n -r capstone-bpf.pcap 'ip[6] &32 = 32 || ip[6:2] & 8191 > 0' | wc -l

02 PCAP 3
tcpdump -n -r capstone-bpf.pcap 'ip[6] & 64 = 64  && tcp[13]= 5' | wc -l

02 PCAP 4
tcpdump -n -r capstone-bpf.pcap 'ip[12:4]=0x0A000068 && tcp[13]= 18' | wc -l

```

![image-20251204110749388](../Images/image-20251204110749388.png)

```bash

Capstone v2 03
03 Web Question 1
KERNEL

03 Socket 
ssh net7_student4@10.50.134.55 -L 1111:10.1.1.25:4869 -NT

04 Malware Discovery
tcpdump -i eth1 -X 'udp[2:2]=69'

04 IP Discovery
tcpdump 'udp[0:2]=520 || udp[2:2]=520' -nvvXX

07 Credential Farming
tcpdump -nvvXX 'ip[12:4]=0x0A020207 && tcp[2:2]=23'
net7_comrade4
H0ld 73h d00r?
```

```bash
Capstone - 11 Web Question 4
echo 'proxychains scp tgt@192.168.1.10:secret.txt .' | base64

alien-abductions.rules

telnet 
Capstone 7 - ssh net7_student4@10.2.2.6 -R 10401:localhost:2222 -NT
Blue Internet Host - ssh net7_student@10.50.158.236 -L 10402:localhost:10401 -NT
ssh net7_comrade@localhost -p 10402

ssh net7_comrade@localhost -p 10402 -L 10403:10.10.10.167:404 -NT
ssh net7_student4@localhost -p 10403 


ssh net7_student4@localhost -p 10403 -D 9050 -NT

```

![ ](../Images/Untitled Diagram.drawio (9).png)
