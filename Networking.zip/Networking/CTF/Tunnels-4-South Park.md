```
I learned something today. Sometimes, the right thing to do is nothing!
```

![Untitled Diagram.drawio (7)](../Images/Untitled Diagram.drawio (7).png)