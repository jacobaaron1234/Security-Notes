```bash
tcp.port==443 and ip contains "http"
# Wireshark filter for HTTPS

#When looking for MSS - We need to be looking at TCP SYN packets. Look for SYN packets around the protocol you are analyzing 
```

