[TOC]

# IPv4 Header

## Normal items

```bash
# Total Length
'ip[2:2] = 100' # Change out 100 for your filtered total length.

# Identification 
'ip[4:2] = 123' # Change out 123 for your filtered ID

# Fragment Offset
'ip[6:2] & 0x1FFF = 125' # Multiple by 8 to convert to bytes

# TTL 
'ip[8] = 255' # Change 255 to your filtered TTL
# Windows default = 128
# Linux default = 64
# Cisco default = 255
'ip[8] = 1' # Search for incoming TTL

# ECN
'ip[1] & 0x03 = ' #Enter ECN value you are searching for | use !=0 for all

# DSCP
'ip[1] & 252 = 192' # The value I want to match is 192
'ip[1] & 0xFC = 0xC0' # Hex version
'ip[1] >> 2 = 14' # No multiply by 4

# Protocol 
'ip[9]=17' # Change 17 to to one of the IANA protcol numbers. 17 is UDP
https://www.iana.org/assignments/protocol-numbers/protocol-numbers.xhtml

# Header Checksum
'ip[10:2] = 0x4051' # Default checksum search

# Source and Destination Address
'src host 1.1.1.1' # For one host
'src net 1.1.1.0/24' # For a full network

'dst host 1.1.1.1' # For one host
'dst net 1.1.1.0/24' # For a full network
```

## Fragmentation 

```bash
# HEX
'ip[6] & 0xE0 = ' #All three, specify which ones you want
'ip[6] & 0xE0 = 0x20' # More frag
'ip[6] & 0xE0 = 0x40' # Do not frag
'ip[6] & 0xE0 = 0x80' # No frag (RES)

# DECIMAL
'ip[6] & 224 = ' #All three, specify which ones you want
'ip[6] = 128' # Reserved bit (no frag)
'ip[6] = 64' # Do not frag
'ip[6] = 32' # More frag

# Search for offset field having any value greater than 0
'ip[6:2] & 0x1fff > 0'

# Search for MF set or offset value greater than 0
'ip[6] & 0x20 = 0x20 || ip[6:2] & 0x1fff > 0' 
```

# TCP

```bash
# Search for port
'tcp[0:2] = 123'

# Search either port
'tcp[0:2] = 53 || tcp[2:2] = 80' # First half is source port, second half is destination port

# Sequence Number
'tcp[4:4] = 0'

# Acknolwedgement Number
'tcp[8:4] = 0'
```

## TCP Flags

```bash
# Reserved
'tcp[12] & 0x05 = 0'

# Offset
'tcp[12] & 0xf0 = 0x50' # Specifies the size of TCP header in 32bit words minimum 20B and max 60B

# NONCE
'tcp[12] & 0x01 = 1' 

# CWR
'tcp[13]=128'

# ECE / ECN / Echo
'tcp[13]=64'

# URG
'tcp[13]=32'

# ACK
'tcp[13]=16'

# PSH
'tcp[13]=8'

# RST
'tcp[13]=4'

# SYN
'tcp[13]=2'

# FIN
'tcp[13]=1'

# ACK + PSH
'tcp[13] = 24' # Only packets with ACK + PSH flags set and NO other flags

# ACK + FIN
'tcp[13] = 0x11'
```

# Type II Frame

```bash
# Destination MAC
'ether[0:4] = 0xFFFFFFFF && ether[4:2] = 0xFFFF' 

# Source MAC
'ether[6:4] = 0xFFFFFFFF && ether[10:2] = 0xFFFF'

# OUI
'ether[0:4] & 0xFFFFFF00 = 0xFFFFFF00'

# Ether Type
'ether[12:2]= '

# Ether types:
0x0800 = IPv4
0x0806 = ARP
0x86DD = IPv6
0x8100 = VLAN Tag
```

# 802.1q Tag

```bash
# Vlan Ether Type and VLAN Tag. Change xxx to VLAN number in Hex
'ether[12:2] = 0x8100 && ether[14:2] & 0x0FFF = 0x0xxx'

# VLAN ID and Tag. Change xxx to VLAN number in Hex. 
'ether[12:4] & 0xFFFF0FFF = 0x81000xxx'
'ether[12:4] & 0xFFFF0FFF = 0x8100064' # Searches for VLAN 100 (64 from hex to decimal is 100)

# Two VLAN IDs. Searches for VLAN 1 and VLAN 100
'ether[16:2] = 0x0001 && ether[18:2] = 0x0064'
```

# IPv6

```bash
# High nibble: IP Version (HEX)
'ip6[0] & 0xf0 ='

# High nibble: IP Version (Decimal)
'ip6[0] & 240 = '

# Payload Length
'ip6[4:2]=0x0020'

# Hop limit
'ip6[7] = 0x31'

# Next Header
'ip6[6] = 0x06'

# Source Address
'src host 2607:f8b0:4002:c09::5e'

# Destination Address
'dst host 2a00:e040:c0c:4501::157'



```



<img src="../Images/image-20251119081647118.png" alt="image-20251119081647118" style="zoom:150%;" />

[raw.githubusercontent.com/sbabicz/tcpdump-bpf-cheatsheet/43f6e80f8d92ca91c94158c6e246d1f1191cd763/TCPDUMP_OFFSETS_HTML_v2.2.svg](https://raw.githubusercontent.com/sbabicz/tcpdump-bpf-cheatsheet/43f6e80f8d92ca91c94158c6e246d1f1191cd763/TCPDUMP_OFFSETS_HTML_v2.2.svg)