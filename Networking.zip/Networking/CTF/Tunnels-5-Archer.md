```
Am I a terrible person? Yes, but that is what makes me so damn lovable.
Y4fNp7LdVz
```

![Untitled Diagram.drawio (8)](../Images/Untitled Diagram.drawio (8).png)
