```bash
/usr/share/cctc # Has useful info for the flags! On all boxes. 

Creds:
Router - vyos/password

host - net7_student4 / password4

#Banner Grab UDP
nc -u 172.16.182.110 1989

# Use the below for admin email lookup
https://sitereport.netcraft.com/
```



![CCTC_Net.drawio (3)](../Images/CCTC_Net.drawio (3).png)
