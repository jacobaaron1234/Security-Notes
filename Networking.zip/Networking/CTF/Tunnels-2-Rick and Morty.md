10.50.87.199

The universe is a simulation, and we are all just a bunch of bugs 

Z7kLp4vQmX

```bash
wget -r 10.50.87.199
telnet 10.50.87.199 # Username Rick
ssh student@10.50.22.100 -R 10400:localhost:22 -NT #Establish remote port
ssh Rick@localhost -p 10400 -D 9050 -NT #Setup D tunnel

proxychains ./scan.sh # For new IP, 10.1.12.18/28
proxychains wget ftp://10.1.12.18
proxychains wget 10.1.12.18
proxychains scp -P 10400 Rick@localhost:/usr/share/cctc/Rick-share.png .

proxychains scp -P 1111 Morty@localhost:/usr/share/cctc/Morty-share.png . # Didn't work but should have

ssh Morty@localhost -p 1111 -L 2222:172.16.10.121:2323 -NT
ssh Jerry@localhost -p 2222 -D 9050 -NT


proxychains nc localhost 54321

```

![image-20251201075946104](../Images/image-20251201075946104.png)

![Untitled Diagram.drawio (4)](../Images/Untitled Diagram.drawio (4).png)

