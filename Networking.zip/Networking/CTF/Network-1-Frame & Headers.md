```bash
# bgp 

# Look for "UPDATE Message" for advertising subnets	

# AS = Autonomous System Number 
```

