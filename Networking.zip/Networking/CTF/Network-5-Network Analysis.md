```bash
student@blue-internet-host:~$ p0f -r ~/Downloads/attack_analysis1.pcap | grep 192.168.10.101 -C 5 | head -n 10

27
85054 

ip contains "axis2"

ip.addr == 192.168.10.111 && http && http.request.method == POST

29
tcp.stream eq 328

31
ip.addr == 192.168.10.111 && http && ip contains "filename"

35
ip contains "PAYLOAD_UUID"
tcp.stream eq 508

37
tcp.stream eq 515
search for github

38
tcp.stream eq 515
search for UUID

39
tcp.stream eq 515
search for github

41 & 42
tcp.stream eq 515
look at the bottom of the stream



```

