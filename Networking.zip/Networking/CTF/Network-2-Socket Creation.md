```bash
# When changing DSCP within a socket, we need to multiple the DSCP value by 4. 
# Given: DSCP 24
# In script: 96
```

