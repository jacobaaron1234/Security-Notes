```bash
# We use the below for this CTF generaly
sudo tcpdump -n 'filter syntax' -r /home/activity_resources/pcaps/BPFCheck.pcap | wc -l

# Search for TTL of 64 or less, with IPv4 or IPv6
ip[8]<=0x40 || ip6[7]<=0x40

#IPv4 packets with at least the Don't Fragment bit set
ip[6]&64= 64

# All ports above 1024 (UDP and TCP)
tcp[0:2]>1024 || udp[0:2]>1024

# Searches for IPv6 and IPv4 UDP traffic
ip6[6]=17 || ip[9]=17

# Search for ACK/RST or ACK/FIN
tcp[13]=17 || tcp[13]=20

# Search for UDP/ICMP and TTL 1 (traceroute with TTL value 1)
(ip[9]=17 || ip[9]=1) && ip[8]=1

# All traffic on 53 (Source / Destination)
tcp[0:2]=53 || tcp[2:2]=53 || udp[0:2]=53 || udp[2:2]=53

# All traffic to well known ports
tcp[2:2]<1024 || udp[2:2]<1024

# All traffic to port 80 / HTTP
tcp[2:2]=80 || tcp[0:2]=80

# All trafic to Telnet
tcp[2:2]=23 || tcp[0:2]=23

# Vlan hopping from 1 to 10 - Double tagged
ether[12:4] & 0xffff0fff = 0x81000001 && ether[16:4] & 0xffff0fff = 0x8100000A

# Reserved bit or 'evil bit' set
ip[6] & 128=128

# URG flag not set and URG pointer is has a value
tcp[13] & 32 != 32 && tcp[18:2] !=0

# TCP Null scan to host 10.10.10.10
tcp[13]=0 && ip[16:4]=0x0A0A0A0A

# CHAOS protocol search
ip[9]=16
```

