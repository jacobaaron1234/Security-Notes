```bash
Flag: When we hit our lowest point, we are open to the greatest change
add_the_touch_of_the_waves.salt --> aX9tR2pQwL

nmap 10.50.176.142 -p- #Identify all open ports
firefox 10.50.176.142:8888

ssh Sokka@10.50.176.142
ip a
ssh Sokka@10.50.176.142 -D 9050 -NT
proxychains ./scan.sh # Look for new found network (192.168.1.39)

#Enumerate new hosts
proxychains wget -r 192.168.1.39
proxychains wget -r ftp://192.168.1.39

#Build new tunnel to Aang
ssh Sokka@10.50.176.142 -L 1111:192.168.1.39:22 -NT
ssh Aang@localhost -p 1111

#Build new -D tunnel
ssh Aang@localhost -p 1111 -D 9050 -NT

#Enumerate new hosts
proxychains scp -p 1111 Aang@localhost:/usr/share/cctc/Aang-share.png .
proxychains wget -r 10.0.0.50
proxychains wget -r ftp://10.0.0.50

#Build new tunnel to Katara
ssh Aang@localhost -p 1111 -L 2222:10.0.0.50:22 -NT
ssh Katara@localhost -p 2222

#Build new -D tunnel
ssh Katara@localhost -p 2222 -D 9050 -NT

#Enuemrate new hosts
proxychains wget -r 172.16.1.8 
proxychains wget -r ftp://172.16.1.18
proxychains scp -p 2222 Katara@localhost:/usr/share/cctc/Katara-share.png .

#Build new tunnel to Toph
ssh Katara@localhost -p 2222 -L 3333:172.16.1.8:22 -NT

#Build new -D tunnel
ssh Toph@localhost -p 3333 -D 9050 -NT

# While proxchained to Toph
proxychains nc localhost 12345
proxychains scp -p 3333 Toph@localhost:/usr/share/cctc/Toph-share.png .
```

![Untitled Diagram.drawio (3)](../Images/Untitled Diagram.drawio (3).png)