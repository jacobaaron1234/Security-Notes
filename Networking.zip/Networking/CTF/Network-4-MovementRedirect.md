```bash

6.  A. ssh -L 1111:localhost:22 cctc@10.50.1.150 -NT 

7.  B. ssh cctc@10.50.1.150 -L 1111:localhost:80 -NT 

8.  D. ssh -D 9050 cctc@localhost -p 1111 -NT 

9.  C. wget -r http://localhost:1111 

10.  B. proxychains wget -r http://100.1.1.2 

11.  D. ssh cctc@10.50.1.150 -L 1111:100.1.1.2:22 -NT 

12. A. ssh -L 2222:100.1.1.2:22 cctc@localhost -p 1111 -NT 

13.  B. ssh cctc@localhost -p 1111 -L 2222:100.1.1.2:80 -NT 

14. A. ssh -D 9050 cctc@localhost -p 2222 -NT 

15.  C. authenticated to wrong IP in line 2 

16. A. targeted wrong IP in line 1 

17.  D. ssh -p 2222 cctc@localhost -L 3333:192.168.2.2:23 -NT 

18.  B. telnet localhost 3333 

19.  C. ssh -R 4444:localhost:22 cctc@192.168.2.1 -NT 

20. A. ssh cctc@localhost -p 2222 -L 5555:localhost:4444 -NT 

```

```bash
# Tunnels Training - Cortina HTTP
nmap -Pn 10.50.11.22 #Need -Pn to disable the ping sweep
ssh net7_student4@10.50.11.222 # Discover stuff
ssh net7_student4@10.50.11.222 -D 9050 #Setup D port for scanning
proxychains ./scan.sh #Find more hosts
proxychains wget -r 10.3.0.1 #Scrub the HTTP

# Tunnels Training - Cortina FTP
proxychains wget -r ftp://10.3.0.1 #Using the Dynamic port prior created

# Tunnels Training - Victoria HTTP
proxychains wget -r 10.3.0.27 #Using the Dynamic port created prior

# Tunnels Training - Victoria FTP
proxychains wget -r ftp://10.3.0.27 # Using the Dynamic port created prior

# Tunnels Training - Pineland
nmap 10.50.200.173 -Pn
telnet 10.50.200.173 # username: net7_student4     password: password4
ls /usr/share/cctc

# Tunnels Training - Mohammed HTTP
telnet 10.50.200.173
Identify new IP space - 10.2.0.0/24
ssh net7_student4@10.3.0.10 -R 10401:localhost:22 -NT #On tunnels-training-pineland-insider
ssh net7_student4@10.50.11.222 -L 2222:localhost:10401 -NT # On internet-host, build local port for the remote SSH you just made
ssh net7_student4@localhost -p 2222 -D 9050 -NT #create Dynamic tunnel
proxychains wget -r 10.2.0.2

# Tunnels Training - Mohammed FTP
proxychains wget -r ftp://10.2.0.2 #using steps above

# Tunnels Training - Mojave FTP (Questions 8-11)
# Identify the hint on 10.2.0.3 - Networks 10.4.0.0/24 and 10.5.0.0/24 are present but not connected to 10.2.0.3
telnet 10.50.200.173 # on blue host
ssh 10.2.0.3 # To get into training -atlantica-pivot
cat /usr/share/cctc/hint.txt

#setup -D tunnel to 10.50.11.222
ssh net7_student4@10.50.11.222 -D 9050
proxychains ./scan.sh #Look for 10.4.0.1/24

#Build tunnel to 10.4.0.1
ssh net7_student4@10.50.11.222 -L 4444:10.4.0.1:22 -NT
#Set up -D tunnel to 10.4.0.1
ssh net7_student4@localhost -p 4444 -D 9050 -NT

#Enumerate for information 
proxychains ./scan.sh #Look for 10.5.0.0/24

proxychains wget for stuff 
```

![Untitled Diagram.drawio (1)](../Images/Untitled Diagram.drawio (1).png)



```bash
# SSH-01
ssh student@10.50.22.100 -R 10401:localhost:22 -NT # Assign 10401 on localhost for SSH
ssh net7_student4@localhost -p 10401 -D 9050 -NT # Build -D tunnel to T5
proxychains wget -r -P 10401 localhost # Grab the items on T5 web server

#SSH-03
proxychains wget -r 192.168.0.30 #Provides a hint to the open ssh port
proxychains nc 192.168.0.30 4444 # Banner grab for question 

#SSH-02 Pivot
Look at network map

# SSH-02 Flag
proxychains wget -r ftp://192.168.0.20

# SSH-05 Flag
proxychains ./scan.sh # Find more ports on .20
ssh net7_student4@localhost -p 10401 -L 1111:192.168.0.20:3333 -NT #on blue internet
ssh net7_student4@localhost -p 1111 -D 9050 -NT # On blue internet 
proxychains ./scan.sh #Enumerate 192.168.0.0/24 for more IPs
proxychains wget -r ftp://192.168.0.50

# SSH-06 Flag
ssh net7_student4@localhost -p 10401 -D 9050 -NT # Switch -D tunnel back to T5
proxychains wget -r 192.168.0.40 

# SSH-04 Pivot
ssh net7_student4@localhost -p 10401 -L 2222:192.168.0.40:5555 -NT #Setup L port to SSH-04
ssh net7_student4@localhost -p 2222 -D 9050 -NT # Setup -D port through SSH-04
proxychains wget -r 192.168.0.40 # Check hint
172.16.0.60/24

# SSH-06 Flag
proxychains wget -r 172.16.0.60

# SSH-08 Flag
net7_comrade4 :: privet4
ssh net7_student4@localhost -p 2222 -L 3333:172.16.0.60:23 -NT #Setup tunnel to .60
ssh net7_student4@192.168.0.40 -p 5555 -R 10402:localhost:22 -NT #Remote port to 192.168.0.40 to allow for .60 ssh. Done on 172.16.0.60 via the telnet connection
ssh net7_student4@localhost -p 2222 -L 4444:localhost:10402 -NT

ssh net7_comrade4@localhost -p 4444 -D 9050 -NT #Adjust -D tunnel
proxychains wget -r 172.16.0.80 #Two good hints for -08 and -07
proxychains nc 172.16.0.80 3389 

# SSH-09 Flag
proxychains wget -r ftp://172.16.0.90
proxychains wget -r 172.16.0.90

# SSH-09 Pivot
proxychains ./scan.sh #Find high port
ssh net7_comrade4@localhost -p 4444 -L 5555:172.16.0.90:2222 -NT #New tunnel to .90
ssh net7_comrade4@localhost -p 5555 -D 9050 -NT #New -D tunnel to .90
ssh net7_comrade4@localhost -p 5555
ip neigh

# SSH-10 Flag
proxychains wget -r 172.16.0.100 #Good hint
ssh net7_comrade4@localhost -p 5555 -L 6666:172.16.0.100:23 -NT
telnet localhost 6666
tcpdump -vvvX 'icmp'
tcpdump -vvvX 'not tcp port 23' #also works
```

![Untitled Diagram.drawio (2)](../Images/Untitled Diagram.drawio (2).png)

